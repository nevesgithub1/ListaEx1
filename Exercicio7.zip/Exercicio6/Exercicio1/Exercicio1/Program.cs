﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio1
{
    internal class Program
    {
        static void Main(string[] args)

        {
            double numero1;
           double numero2;
            double resultado;

            Console.WriteLine("Calculo Milha Maritima");

            Console.Write("Digite numero 1:");
            numero1 = double.Parse(Console.ReadLine());


           numero2 = 1.85;

            resultado = (numero1 * numero2);
       
            Console.WriteLine("O resultado em KM é: {0}", resultado);


          

            
        }
    }
}
