﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio1
{
    internal class Program
    {
        static void Main(string[] args)

        {
            double numero1;
            double numero2;
            double resultado;

            Console.WriteLine("Calculo da Area de um Retangulo");

            Console.Write("Digite a altura:");
            numero1 = double.Parse(Console.ReadLine());


            Console.Write("Digite a base:");
            numero2 = double.Parse(Console.ReadLine());

            resultado = (numero1 * numero2);
       
            Console.WriteLine("O resultado da area é {0}", resultado);


          

            
        }
    }
}
