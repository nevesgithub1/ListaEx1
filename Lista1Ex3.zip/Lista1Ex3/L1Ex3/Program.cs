﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1Ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double d;
            double A;
            double L;

            Console.Write("Digite o valor da diagonal do quadrado:");
            d = double.Parse(Console.ReadLine());

            L = d / Math.Sqrt(2);

            A = L * L;

            Console.WriteLine("O resultado da área do quadrado é: {0}", A);



             

        }
    }
}
