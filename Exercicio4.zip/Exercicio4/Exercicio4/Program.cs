﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Base;
            double Altura;
            double Area;

            Console.WriteLine("Calculo da Area de um Triangulo");

            Console.WriteLine("Digite o valor da base: ");
            Base = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da Altura:");
            Altura = double.Parse(Console.ReadLine());

            Area = (Base * Altura / 2);

            Console.WriteLine("A area deste Triangulo é {0}", Area);
        }
    }
}
