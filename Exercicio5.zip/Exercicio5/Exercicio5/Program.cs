﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double Valor1;
            double Valor2;
            double Valor3;
            double Valor4;
            double soma;
            double média;

            Console.WriteLine("Média Aritimética");

            Console.WriteLine("Digite o valor1: ");
            Valor1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor2: ");
            Valor2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor3: ");
            Valor3 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor4: ");
            Valor4 = double.Parse(Console.ReadLine());


            soma = (Valor1 + Valor2 + Valor3 + Valor4);
            média = (soma / 4);
            Console.WriteLine("A média Aritimética dos valores é {0}", média);
        }
    }
}
