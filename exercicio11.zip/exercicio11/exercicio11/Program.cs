﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio11
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double numero1;
            double numero2;
            double resultado;

            Console.WriteLine("X elevado a Y");

            Console.WriteLine("Digite o valor de X");
            numero1 =   double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor de Y");
            numero2 = double.Parse(Console.ReadLine());

            resultado = Math.Pow(numero1, numero2);

            Console.WriteLine("O valor dessa elevação é {0}", resultado);

        }
    }
}
