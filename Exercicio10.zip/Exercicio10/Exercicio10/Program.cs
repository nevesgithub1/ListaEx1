﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio10
{
    internal class Program
    {
        static void Main(string[] args)

        {
            double numero1;

            double resultado;

            Console.WriteLine("Dolar para reais");

            Console.WriteLine("Digite o valor em dolar");
            numero1 = double.Parse(Console.ReadLine());

            resultado = numero1 * 4.97; 

            Console.WriteLine("O valor em reais é {0}", resultado);





        }
    }
}
