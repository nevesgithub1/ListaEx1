﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double numero1;
            double resultado;

            Console.WriteLine("Area de um Circulo ");

            Console.Write("Digite seu diametro:");
            numero1 = double.Parse(Console.ReadLine());


            resultado = (numero1 * numero1) * 3.14 ;

            Console.WriteLine("O resultado da area do circulo em m² é: {0}", resultado);
        }
    }
}
