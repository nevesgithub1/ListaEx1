﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double numero1;
            double resultado;

            Console.WriteLine("Temperatura °C para °F ");

            Console.Write("Digite a temperatura em °C:");
            numero1 = double.Parse(Console.ReadLine());


            resultado = (numero1 * 9/5) + 32 ;

            Console.WriteLine("O resultado em °F é: {0}", resultado);

        }
    }
}
