﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio1
{
    internal class Program
    {
        static void Main(string[] args)

        {
            double numero1;
            double numero2;
            double resultado;

            Console.WriteLine("Calculo da media geometrica");

            Console.Write("Digite numero 1:");
            numero1 = double.Parse(Console.ReadLine());


            Console.Write("Digite numero 2:");
            numero2 = double.Parse(Console.ReadLine());

            resultado = Math.Sqrt(numero1 * numero2);
       
            Console.WriteLine("O resultado da media geometrica {0}", resultado);


          

            
        }
    }
}
