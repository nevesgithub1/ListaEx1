﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double L;
            double A;

            Console.Write("Digite o valor da aresta do quadrado: ");
            L = double.Parse(Console.ReadLine());

            A = L * L;

            Console.WriteLine("A área do quadrado é igual a: {0}", A);
            


        }
    }
}
