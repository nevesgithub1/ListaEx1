﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exericio12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double produto1;
            double produto2;
            double produto3;
            double produto4;
            double produto5;
            double pagamento;
            double resultado;

            Console.WriteLine("Troco dos valores de produtos");
            
            Console.Write("Valor de pagamento:");
            pagamento = double.Parse(Console.ReadLine());

            produto1 = 7;
            produto2 = 5;
            produto3 = 6;
            produto4 = 4;
            produto5 = 3;

           
            resultado = pagamento-(produto1+produto2+produto3+produto4+produto5);

            Console.Write("seu troco é: {0}", resultado);
            Console.WriteLine();
        }
    }
}
